<?php

$conn = new mysqli("sql312.infinityfree.com", "if0_42361977", "Maather17", "if0_42361977_table");


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["Name"];
    $age = $_POST["Age"];

    $stmt = $conn->prepare("INSERT INTO users (Name, Age, Status) VALUES (?, ?, 0)");
    $stmt->bind_param("si", $name, $age);
    $stmt->execute();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Simple System</title>

<style>
body {
    font-family: Arial;
    background: #f4f6f9;
    text-align: center;
}

form {
    margin: 20px;
}

input {
    padding: 8px;
    margin: 5px;
}

button {
    padding: 8px 15px;
    background: #007bff;
    color: white;
    border: none;
    cursor: pointer;
}

table {
    margin: auto;
    border-collapse: collapse;
    width: 70%;
    background: white;
}

th, td {
    border: 1px solid #ddd;
    padding: 10px;
}

th {
    background: #007bff;
    color: white;
}

.toggle-btn {
    background: green;
    color: white;
    padding: 5px 10px;
    border-radius: 5px;
    cursor: pointer;
}

.edit-btn {
    background: orange;
    color: white;
    padding: 5px 10px;
    text-decoration: none;
    border-radius: 5px;
}

.delete-btn {
    background: red;
    color: white;
    padding: 5px 10px;
    text-decoration: none;
    border-radius: 5px;
}
</style>
</head>

<body>

<h2>User Form</h2>

<form method="POST">
    <input type="text" name="Name" placeholder="Name" required>
    <input type="number" name="Age" placeholder="Age" required>
    <button type="submit">Add</button>
</form>

<table>
<tr>
    <th>ID</th>
    <th>Name</th>
    <th>Age</th>
    <th>Status</th>
    <th>Action</th>
</tr>

<?php
$result = $conn->query("SELECT * FROM users");

while($row = $result->fetch_assoc()) {
    echo "<tr>
        <td>{$row['ID']}</td>
        <td>{$row['Name']}</td>
        <td>{$row['Age']}</td>

        <td id='status-{$row['ID']}'>" . ($row['Status'] == 1 ? "Active" : "Inactive") . "</td>

        <td>
            <span class='toggle-btn' onclick='toggleStatus({$row['ID']})'>Toggle</span> |
            <a href='edit.php?id={$row['ID']}' class='edit-btn'>Edit</a> |
            <a href='delete.php?id={$row['ID']}' class='delete-btn' onclick=\"return confirm('Are you sure?')\">Delete</a>
        </td>
    </tr>";
}
?>

</table>

 
<script>
function toggleStatus(id) {
    fetch("toggle.php?id=" + id)
    .then(response => response.text())
    .then(newStatus => {
        let statusCell = document.getElementById("status-" + id);

        if (newStatus == 1) {
            statusCell.innerHTML = "<span style='color:green;'>Active</span>";
        } else {
            statusCell.innerHTML = "<span style='color:red;'>Inactive</span>";
        }
    });
}
</script>

</body>
</html>