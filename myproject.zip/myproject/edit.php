<?php
$conn = new mysqli("sql312.infinityfree.com", "if0_42361977", "Maather17", "if0_42361977_table");

$id = $_GET['id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $age = $_POST['age'];

    $conn->query("UPDATE users SET name='$name', age='$age' WHERE ID=$id");
    header("Location: index.php");
}

$result = $conn->query("SELECT * FROM users WHERE ID=$id");
$row = $result->fetch_assoc();
?>

<form method="POST">
    <input type="text" name="name" value="<?php echo $row['name']; ?>">
    <input type="number" name="age" value="<?php echo $row['age']; ?>">
    <button type="submit">Update</button>
</form>

