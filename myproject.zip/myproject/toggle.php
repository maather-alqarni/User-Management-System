<?php

$conn = new mysqli("sql312.infinityfree.com", "if0_42361977", "Maather17", "if0_42361977_table");


if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $conn->query("UPDATE users SET Status = 1 - Status WHERE ID = $id");

    $result = $conn->query("SELECT Status FROM users WHERE ID = $id");
    $row = $result->fetch_assoc();

    echo $row['Status'];
}
?>





